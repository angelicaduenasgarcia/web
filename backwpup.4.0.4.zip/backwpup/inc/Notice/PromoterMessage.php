<?php

// -*- coding: utf-8 -*-

namespace Inpsyde\BackWPup\Notice;

class PromoterMessage
{
    public function defaults()
    {
        return [];
    }
}
