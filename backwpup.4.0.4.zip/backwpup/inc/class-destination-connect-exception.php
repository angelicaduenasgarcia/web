<?php
/**
 * Destination Connect Exception.
 *
 * @since   3.5.0
 */

/**
 * Class BackWPup_Destination_Connect_Exception.
 *
 * @since   3.5.0
 */
class BackWPup_Destination_Connect_Exception extends \RuntimeException
{
}
